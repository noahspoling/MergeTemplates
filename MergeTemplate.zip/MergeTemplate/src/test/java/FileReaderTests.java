import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.noahspoling.Models.FileReader;
import org.noahspoling.Models.*;
import java.util.Arrays;
import java.util.List;
class FileReaderTest {

    private FileReader fileReader;

    @BeforeEach
    void setUp() {
        // setup method that runs before each test
        // creates a list of templates from given file
        fileReader = new FileReader("mergefile.txt");
    }

    //Tests if list is not null
    @Test
    void testConstructorWithFilename() {
        assertNotNull(fileReader.getTemplates());
    }

    //checks if list matches what it's supposed to
    @Test
    void testConstructorWithTemplateList() {
        List<Template> templates = Arrays.asList(
                new TemplateA("TestTemplateA", "John Doe", "parachute", "jetpack", "$100.00"),
                new TemplateB("TestTemplateB", "John Doe", "jetpack", "01/01/1990", "$50 ACME Gift Card", "five lucky winners"),
                new TemplateA("TestTemplateA", "John Doe", "hang glider", "jetpack", "$300.00"),
                new TemplateB("TestTemplateB", "John Doe", "parachute", "01/01/1991", "$250 ACME Gift Card", "one lucky winner")
        );
        FileReader fileReaderWithList = new FileReader(templates);
        assertEquals(templates, fileReaderWithList.getTemplates());
    }

    @Test
    void testReadFromTxt() {
        fileReader.readFromTxt("mergefile.txt");
        assertNotNull(fileReader.getTemplates());
    }

    @Test
    void testGenerateTemplateA() {
        String[] entries = new String[] {"TestTemplateA", "John Doe", "parachute", "jetpack", "$100.00"};
        Template template = fileReader.generateTemplate(entries);
        assertNotNull(template);
        assertEquals("TestTemplateA", template.getType());
    }

    @Test
    void testGenerateTemplateB() {
        String[] entries = new String[] {"TestTemplateB", "entry1", "entry2", "entry3", "entry4", "entry5"};
        Template template = fileReader.generateTemplate(entries);
        assertNotNull(template);
        assertEquals("TestTemplateB", template.getType());
    }

    @Test
    void testGetTemplates() {
        assertNotNull(fileReader.getTemplates());
    }
}
