package org.noahspoling.Models;

import java.util.List;

public interface IFileReader {

    /**
     * From example txt file, generates an array of Strings by splitting on |
     */
    public void readFromTxt(String filename);


    /**
     * From a string array of formatted values return a child of the abstract template class
     * first index is the template type.
     * @param entries
     * @return Template
     */
    public Template generateTemplate(String[] entries);

    /**
     * From a list of template classes. Fill in placeholder values
     * @param values
     * @type List<Template>
     */
    public void createFiles(List<Template> values);

    public void outputFromTemplate(Template template, String filetype);

    public List<Template> getTemplates();

    public void setTemplates(List<Template> templates);

}
