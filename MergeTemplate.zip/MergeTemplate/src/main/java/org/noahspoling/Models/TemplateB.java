package org.noahspoling.Models;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class TemplateB extends Template{
    private String name;
    private String item;
    private String date;
    private String reward;
    private String numOfWinners;

    public TemplateB(String type, String name, String item, String date, String reward, String numOfWinners) {
        super(type);
        this.setName(name);
        this.setItem(item);
        this.setDate(date);
        this.setReward(reward);
        this.setNumOfWinners(numOfWinners);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getReward() {
        return reward;
    }

    public void setReward(String reward) {
        this.reward = reward;
    }

    public String getNumOfWinners() {
        return numOfWinners;
    }

    public void setNumOfWinners(String numOfWinners) {
        this.numOfWinners = numOfWinners;
    }

    @Override
    public List<String> getEntries() {
        List<String> entries = new ArrayList<String>();
        Field[] fields = this.getClass().getDeclaredFields();
        for(Field field : fields) {
            //to access private fields
            field.setAccessible(true);
            try {
                Object value = field.get(this);
                entries.add(value.toString());
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        return entries;
    }
}
