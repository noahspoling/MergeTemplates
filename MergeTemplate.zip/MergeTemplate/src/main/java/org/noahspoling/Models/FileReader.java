package org.noahspoling.Models;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.util.Units;
import org.apache.poi.xwpf.usermodel.*;

import java.io.*;
import java.util.*;

public class FileReader implements IFileReader{
    public static Map< Integer, String> placeholders = new HashMap<>();
    static {
        for (int i = 1; i <= 10; i++) {
            FileReader.placeholders.put(i-1, "{mergefield"+i+"}");
        }
    }
    private List<Template> templates = new ArrayList<Template>();


    //Constructor that calls method that satisfies the requirements and pattern of text file
    public FileReader(String filename) {
        this.readFromTxt(filename);
    }


    //Constructor using list of Templates from other sources

    public FileReader(List<Template> templatesList) {
        this.templates = templatesList;
    }

    @Override
    public void readFromTxt(String filename) {
        BufferedReader swapValuereader;
        BufferedReader replaceFileReader;
        List<Template> listOfTemplateValues = new ArrayList<Template>();

        try {
            
            String currentWorkingDirectory = System.getProperty("user.dir");

            //Generate os non-specific paths to folders for templates, output, and values
            String valueFile = currentWorkingDirectory + File.separator +"resources"+ File.separator
                    + "values" + File.separator + filename;

            InputStream is = new FileInputStream(new File(valueFile));
            swapValuereader = new BufferedReader(new InputStreamReader(is));
            String line = swapValuereader.readLine();


            //Iterates over lines.
            while (line != null) {
                //splits by |, first value determines the type
                String[] entries = line.split("\\|");
                Template template = this.generateTemplate(entries);
                if(template != null) {
                    this.templates.add(template);
                }
                line = swapValuereader.readLine();
            }
            swapValuereader.close();
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    //converts string array to template
    public Template generateTemplate(String[] entries) {
        if (entries[0].equals("TestTemplateA")) {
            Template templateA = new TemplateA(entries[0], entries[1], entries[2], entries[3], entries[4]);
            return templateA;
        } else if (entries[0].equals("TestTemplateB")) {
            Template templateB = new TemplateB(entries[0], entries[1], entries[2], entries[3], entries[4], entries[5]);
            return templateB;
        } else {
        }
        return null;
    }


    //Given a list of templates with entries, fill out template forms
    @Override
    public void createFiles(List<Template> templates) {
        for (Template template : templates) {
            List<String> fields = template.getEntries();
            this.outputFromTemplate(template, "docx");
        }
    }

    @Override
    public void outputFromTemplate(Template template, String filetype) {

        try {

            //removes a special Character from the default entries array
            String fileName = FileReader.removeSpecialCharacters(template.getEntries().toString());

            //From the location of executable (jar file) get absolute path
            String currentWorkingDirectory = System.getProperty("user.dir");

            //Generate os non-specific paths to folders for templates, output, and values
            String templatePath = currentWorkingDirectory + File.separator +"resources"+ File.separator
                    + "templates" + File.separator + template.getType() + "." + filetype;

            //NOTE This path is for portable jar. Add:
            // File.separator +"src"+ File.separator +"main"+ File.separator + when working with source code resource directory
            String outputPath = currentWorkingDirectory + File.separator+ "resources"+
                    File.separator +"output"+ File.separator + fileName + "." + filetype;
            //Get input output streams
            FileOutputStream outputStream = new FileOutputStream(new File(outputPath));
            FileInputStream inputStream = new FileInputStream(new File(templatePath));


            //reads and creates new document
            XWPFDocument document = new XWPFDocument(inputStream);

            //iterates through the documents paragraph elements
            List<XWPFParagraph> paragraphs = document.getParagraphs();

            //holds pics in separate runs folder
            XWPFParagraph picParagraph = document.createParagraph();
            List<XWPFPictureData> pictureList = picParagraph.getDocument().getAllPictures();

            for(XWPFParagraph paragraph : paragraphs) {
                StringBuilder fullText = new StringBuilder();
                List<XWPFRun> runs = paragraph.getRuns();
                for (int i=0; i < runs.size(); i++) {
                    XWPFRun run = runs.get(i);
                    if(run.getText(0) != null) {
                        fullText.append(run.getText(0));
                    }
                }

                    String filledInText = this.replaceText(fullText.toString(), template.getEntries());
                    if (filledInText != null) {
                        int runCount = runs.size();
                        for (int i = 0; i < runCount; i++) {
                            paragraph.removeRun(0);
                        }

                        XWPFRun newRun = paragraph.createRun();
                        newRun.setText(filledInText, 0);
                    }
                }

            //new document is written and sent to output folder
            for(XWPFPictureData pic : pictureList) {
                XWPFRun picRun = document.getParagraphs().get(0).createRun();
                picRun.setText("", 0);
                picRun.addPicture(new ByteArrayInputStream(pic.getData()),
                        pic.getPictureType(), "", Units.toEMU(180), Units.toEMU(60));
            }
            document.write(outputStream);

            //close input/output streams
            outputStream.close();
            inputStream.close();

        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (InvalidFormatException e) {
            throw new RuntimeException(e);
        }

    }

    public String replaceText(String replaceText, List<String> entries) {

        //If empty
        if (replaceText == null) {
            //throw new IllegalArgumentException("runText cannot be null");
            return "";
        }
        else {
            //System.out.println(entries);
            replaceText = replaceText.replace("\n", "");
            for (int i = 0; i < entries.size(); i++) {

                String targetValue = FileReader.placeholders.get(i);
                //System.out.println(targetValue);
                if(replaceText.contains(targetValue)) {
                    //Ignores the { } in the regex
                    String targetWithEscapes = "\\Q" + targetValue + "\\E";
                    //Handles the format for ignoring $ symbols.
                    //This might need to be handled for all symbol types in the class constructor
                    String formattedEntry = entries.get(i).replace("$", "\\$");
                    replaceText = replaceText.replaceAll(targetWithEscapes, formattedEntry);
                }
            }


            return replaceText;
        }

    }

    public static String removeSpecialCharacters(String fileName) {
        fileName = fileName.replaceAll(" ", "");
        fileName = fileName.replaceAll("\\[", "");
        fileName = fileName.replaceAll("]", "");
        fileName = fileName.replaceAll(",", "");
        fileName = fileName.replaceAll("/", "");

        return fileName;
    }

    public List<Template> getTemplates() {
        return templates;
    }

    public void setTemplates(List<Template> templates) {
        this.templates = templates;
    }
}
