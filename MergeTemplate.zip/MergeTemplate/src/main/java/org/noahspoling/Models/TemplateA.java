package org.noahspoling.Models;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

public class TemplateA extends Template{
    private String name;
    private String item;
    private String replacedItem;
    private String priceDifference;

    public TemplateA(String type, String name, String item, String replacedItem, String priceDifference) {
        super(type);
        this.setName(name);
        this.setItem(item);
        this.setReplacedItem(replacedItem);
        this.setPriceDifference(priceDifference);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getItem() {
        return item;
    }

    public void setItem(String item) {
        this.item = item;
    }

    public String getReplacedItem() {
        return replacedItem;
    }

    public void setReplacedItem(String replacedItem) {
        this.replacedItem = replacedItem;
    }

    public String getPriceDifference() {
        return priceDifference;
    }

    public void setPriceDifference(String priceDifference) {
        this.priceDifference = priceDifference;
    }


    @Override
    public List<String> getEntries() {
        List<String> entries = new ArrayList<String>();
        Field[] fields = this.getClass().getDeclaredFields();
        for(Field field : fields) {
            //to access private fields
            field.setAccessible(true);
            try {
                Object value = field.get(this);
                entries.add(value.toString());
            } catch (IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        return entries;
    }
}
