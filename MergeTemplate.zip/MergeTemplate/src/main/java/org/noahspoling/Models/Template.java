package org.noahspoling.Models;

import java.util.List;

public abstract class Template {

    //abstract parent class for shared type value and storing in a list
    //also declared shared method for accessing private fields
    private String type;

    public Template(String type) {
        this.type = type;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public abstract List<String> getEntries();
}
