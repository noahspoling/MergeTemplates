package org.noahspoling;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.noahspoling.Models.FileReader;
import org.noahspoling.Models.IFileReader;
import org.noahspoling.Models.Template;


import java.io.*;

import org.noahspoling.Models.TemplateA;
import org.noahspoling.Models.TemplateB;

import java.util.ArrayList;
import java.util.List;



public class Main {

    public static void main(String[] args) {

        //handles as a text file with values separated by |
        //can specify filename or default to mergefile.txt
        IFileReader fr;
        if(args.length == 1) {
            fr = new FileReader(args[0]);
        }
        else {
            fr = new FileReader("mergefile.txt");
        }

        System.out.println(fr.getTemplates());
        fr.createFiles(fr.getTemplates());
        
    }
}

