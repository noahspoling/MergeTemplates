#!/bin/bash

#Java Home path
JAVA_HOME=/usr/lib/java-17-openjdk/

#Classpath to your 

#Main class
#Arguments to pass
ARGS="things"